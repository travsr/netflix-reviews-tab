
class Log {
    log(obj) {
        console.log(obj);
    }
}

export default Log;